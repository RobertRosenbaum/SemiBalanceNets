
clear
close all

tstart=tic;

% We want solve an ODE rate model with an f-I curve of the form
% r=f(I)=g*I^a for I>0 and 0 for I<=0. 
% Let's use a=2 for simplicity and choose a g that gives a decent
% fit to the spiking network sims. The code below checks this fit
k=4.4e-5;
f=@(I)(k*(I.^2).*(I>=0));
fprime=@(I)(2*k*I.*(I>=0));
load Fig2A.mat
figure
plot(TotalBarE1Sim,reSim1,'o')
hold on
plot(-50:.01:10,f(-50:.01:10),'r')
legend('Spiking network sim','f-I curve')
xlabel('I')
ylabel('r')

% Rate timescale
tau=15;

% Number of neurons in each pop
Ne=8000*3;
Ni=2000*3;
Nx=2000*3;
N=Ne+Ni;

% Number of neurons in each sub-pop
Ne1=round(Ne/2);
Ne2=Ne-Ne1;
Nx1=round(Nx/2);

Ns=[Ne1 Ne2 Ni];
N=sum(Ns);
Nxs=[.5*Nx .5*Nx];
Nx=sum(Nxs); 

% Mean synaptic weights
Jm=15*[25 25 -150;25 25 -150;112.5 112.5 -250]/sqrt(N);
Jxm=15*[180 180;180 180; 135 135]/sqrt(N);

% Connection probabilities
P=[.05 .15 .1;.15 .05 .1; .1 .1 .1];
Px=[.15 0;0 .15; .15 .15];

% In-degrees
K=repmat(Ns,numel(Ns),1).*P;
Kx=repmat(Nxs,numel(Ns),1).*Px;

% Coupling strength coefficient in mV/kHz
JKbar=mean(mean([abs(Jm).*K abs(Jxm).*Kx]));

% Mean-field connectivity (dimensionless)
W=Jm.*K/JKbar;
Wx=Jxm.*Kx/JKbar;

% Sim time and time step
T=2e3;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Rate of external population
rx2s=[(0:.25:9.4)/1000 (9.5:.1:11)/1000 (12:.25:20)/1000];
rx1s=10/1000+zeros(size(rx2s));
EMaxEig=zeros(size(rx2s));
MaxExcEig=zeros(size(rx2s));
MaxEig=zeros(size(rx2s));
Xs=zeros(3,numel(rx2s));
Es=zeros(3,numel(rx2s));
Is=zeros(3,numel(rx2s));
Ts=zeros(3,numel(rx2s));
ccrit=zeros(size(rx2s));
deltari=zeros(size(rx2s));
for iii=1:numel(rx2s)
      
    rx2=rx2s(iii);
    rx1=rx1s(iii);
    
    
    r=zeros(3,1);
    X=Wx*[rx1; rx2];
    for i=1:numel(time)
        rold=r;
        r=r+dt*(-r+f(JKbar*(W*r+X)))/tau;
    end

    reSim1(iii)=r(1);
    reSim2(iii)=r(2);
    riSim(iii)=r(3);

    rTh=-pinv(W)*X; 

    rThReLu=zeros(size(r));
    I=find(rTh>0);
    rThReLu(I)=-pinv(W(I,I))*X(I);
        
    reTh1ReLu(iii)=rThReLu(1);
    reTh2ReLu(iii)=rThReLu(2);
    riThReLu(iii)=rThReLu(3);
    

    % Jacobian matrix
    A=diag(fprime(JKbar*(W*r+X)))*W*JKbar-eye(3);
    
    
    % Max real part of e-vals
    MaxEig(iii)=max(real(eig(A)));
    
    % Max real part of excitatory sub-matrix
    % to determine whether network is ISN
    AE=A(1:2,1:2);
    MaxExcEig(iii)=max(real(eig(AE)));

    % External, excitatory, inhibitory, and total input to each pop
    Xs(:,iii)=X;
    Es(:,iii)=W(:,1:2)*r(1:2);
    Is(:,iii)=W(:,3)*r(3);
    Ts(:,iii)=W*r+X;
    
    % To check for approximate convergence
    ccrit(iii)=max(abs(rold-r)./r);
    
end
ttotal=toc(tstart)


find(MaxExcEig<0)

clear s st sx J Jee Jei Jie Jii Jx;
save Fig2B.mat

%% Load the data and make the plots
load Fig2B.mat

IsUnstable=find(MaxEig>0)

IsNotISN=find(~(MaxEig<0 & MaxExcEig>0))
IsNotISN2=find(deltari>0)

JJ=find(diff(IsNotISN)>1);
NotISNIntervals=rx2s(sort([IsNotISN(1) IsNotISN(JJ) IsNotISN(JJ+1) IsNotISN(end)]))


lw=2;
fs=26;
e1clr=[.75 .25 .25];
e2clr=[.85 .65 .65];
iclr=[.25 .25 .85];
xclr=[.25 .75 .25];

Eclr=[.6 .1 .1];
Iclr=[.1 .1 .6];
Tclr=[0 0 0];

I=find(rx2s>=0/1000 & rx2s<=22/1000);

figure
plot(1000*rx2s(I),1000*reSim1(I),'Color',min(1.05*e1clr,1),'LineWidth',lw)
hold on
plot(1000*rx2s(I),1000*reSim2(I),'Color',min(1.05*e2clr,1),'LineWidth',lw)
plot(1000*rx2s(I),1000*riSim(I),'Color',iclr,'LineWidth',lw)
plot(1000*rx2s(I),1000*reTh1ReLu(I),'--','Color',.7*e1clr,'LineWidth',lw)
plot(1000*rx2s(I),1000*reTh2ReLu(I),'--','Color',.7*e2clr,'LineWidth',lw)
plot(1000*rx2s(I),1000*riThReLu(I),'--','Color',iclr,'LineWidth',lw)
plot(1000*NotISNIntervals,0+0*NotISNIntervals,'go')
xlabel('rx2 (Hz)')
ylabel('rate (Hz)')
axis tight
axis([-Inf Inf -1.5 20])
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gcf,'Position',[153   516   440  300]*.8)


beta=mean(abs(Ts))./mean(Es+Xs);
figure
plot(1000*rx2s(I),beta,'k','LineWidth',lw)
xlabel('rx2 (Hz)')
ylabel('|E+I|/E')
axis tight
axis([-Inf Inf 0 Inf])
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gca,'ytick',[0 .1 .2 .3])
set(gcf,'Position',[153   516   440  300]*.8)



