
clear
close all

tstart=tic;

% Number of neurons in each pop
Ne=8000*3;
Ni=2000*3;
Nx=2000*3;
N=Ne+Ni;

% Number of neurons in each sub-pop
Ne1=round(Ne/2);
Ne2=Ne-Ne1;
Nx1=round(Nx/2);

Ns=[Ne1 Ne2 Ni];
N=sum(Ns);
Nxs=[.5*Nx .5*Nx];
Nx=sum(Nxs); 

% Mean synaptic weights (units=mV/kHz)
Jm=15*[25 25 -150;25 25 -150;112.5 112.5 -250]/sqrt(N);
Jxm=15*[180 180;180 180; 135 135]/sqrt(N);

% Connection probabilities
P=[.05 .15 .1;.15 .05 .1; .1 .1 .1];
Px=[.08 .1;.1 .1; .12 .12];

% In-degrees
K=repmat(Ns,numel(Ns),1).*P;
Kx=repmat(Nxs,numel(Ns),1).*Px;

% Coupling strength coefficient in mV/kHz
JKbar=mean(mean([abs(Jm).*K abs(Jxm).*Kx]));

% Mean-field connectivity (dimensionless)
W=Jm.*K/JKbar;
Wx=Jxm.*Kx/JKbar;

% Neuron parameters
taum=15;
EL=-72;
Vth=0;
Vre=-72;
Vlb=-85;
DeltaT=1;
VT=-55;
tauw=200;
a=0;
b=.75;

% Synaptic timescales
taue=8;
taui=4;
taux=10;


% Duration for each stim pattern
% and number of times to repeat each pattern
T0=1000;
nreps=1;

% Rates of external population that determine each stim pattern
rx1=[15 15]/1000;
rx2=[15 30]/1000;
nstim=numel(rx1);

% Sim time and time step
T=T0*nreps*nstim;
Tburn=250;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Compute PSP amplitudes
v=GetPSP(taum,taue,0,Jm(1,1),1,EL,100,dt);
PSPEE=max(v)-min(v);
v=GetPSP(taum,taue,0,Jm(3,1),1,EL,100,dt);
PSPIE=max(v)-min(v);
v=GetPSP(taum,taui,0,Jm(1,3),1,EL,100,dt);
PSPEI=max(v)-min(v);
v=GetPSP(taum,taui,0,Jm(3,3),1,EL,100,dt);
PSPII=max(v)-min(v);
v=GetPSP(taum,taux,0,Jxm(1,1),1,EL,100,dt);
PSPEX=max(v)-min(v);
v=GetPSP(taum,taux,0,Jm(3,1),1,EL,100,dt);
PSPIX=max(v)-min(v);
minPSP=min([PSPEE PSPIE PSPEI PSPII PSPEX PSPIX])
maxPSP=max([PSPEE PSPIE PSPEI PSPII PSPEX PSPIX])

% Indices of neurons from which to record currents, voltages
Irecord=1:N;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=1;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

% Generate connectivity matrices
tic
J=([(Jm(1,1)*binornd(1,P(1,1),Ns(1),Ns(1))) ...
   (Jm(1,2)*binornd(1,P(1,2),Ns(1),Ns(2))) ...
   (Jm(1,3)*binornd(1,P(1,3),Ns(1),Ns(3))); ...
   (Jm(2,1)*binornd(1,P(2,1),Ns(2),Ns(1))) ...
   (Jm(2,2)*binornd(1,P(2,2),Ns(2),Ns(2))) ...
   (Jm(2,3)*binornd(1,P(2,3),Ns(2),Ns(3))); ...
   (Jm(3,1)*binornd(1,P(3,1),Ns(3),Ns(1))) ...
   (Jm(3,2)*binornd(1,P(3,2),Ns(3),Ns(2))) ...
   (Jm(3,3)*binornd(1,P(3,3),Ns(3),Ns(3)));]);

Jx=([(Jxm(1,1)*binornd(1,Px(1,1),Ns(1),Nxs(1))) ...
    (Jxm(1,2)*binornd(1,Px(1,2),Ns(1),Nxs(2))); ...
    (Jxm(2,1)*binornd(1,Px(2,1),Ns(2),Nxs(1))) ...
    (Jxm(2,2)*binornd(1,Px(2,2),Ns(2),Nxs(2))); ...
    (Jxm(3,1)*binornd(1,Px(3,1),Ns(3),Nxs(1))) ...
    (Jxm(3,2)*binornd(1,Px(3,2),Ns(3),Nxs(2)));]);    
tGen=toc
disp(sprintf('\nTime to generate connections: %.2f sec',tGen))

% Make Poisson spike times for ffwd layer  
sx=[];
nspikeX=0;
for ii=1:nreps
for jj=1:nstim
    nspikeX1=poissrnd(Nxs(1)*rx1(jj)*T0);
    nspikeX2=poissrnd(Nxs(1)*rx2(jj)*T0);        
    sx(1,nspikeX+(1:nspikeX1))=rand(nspikeX1,1)*T0+T0*(ii-1)*nstim+T0*(jj-1);
    sx(2,nspikeX+(1:nspikeX1))=randi(Nxs(1),1,nspikeX1);
    nspikeX=nspikeX+nspikeX1;
    sx(1,nspikeX+(1:nspikeX2))=rand(nspikeX2,1)*T0+T0*(ii-1)*nstim+T0*(jj-1);
    sx(2,nspikeX+(1:nspikeX2))=Nxs(1)+randi(Nxs(2),1,nspikeX2);
    nspikeX=nspikeX+nspikeX2;
end
end
[st,I]=sort(sx(1,:));
sx(2,:)=sx(2,I);
sx(1,:)=st;

% Random initial voltages
V0=rand(N,1)*(VT-Vre)+Vre;

% Maximum number of spikes for all neurons
% in simulation. Make it 50Hz across all neurons
% If there are more spikes, the simulation will
% terminate
maxns=ceil(.05*N*T);

% Integer division function
IntDivide=@(n,k)(floor((n-1)/k)+1);

% Initialize stuff
V=V0;
w=zeros(N,1);
Ie=zeros(N,1);
Ii=zeros(N,1);
Ix=zeros(N,1);
IeRec=zeros(numrecord,Ntrec);
IiRec=zeros(numrecord,Ntrec);
IxRec=zeros(numrecord,Ntrec);
VRec=zeros(numrecord,Ntrec);
iXspike=1;
s=zeros(2,maxns);
nspike=0;
TooManySpikes=0;

% Euler solver
tic
if(nspikeX==0)
    s=zeros(2,0);
else
for i=1:numel(time)

    % Store recorded variables
    ii=IntDivide(i,nBinsRecord); 
    IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
    IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
    IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord);
    VRec(:,ii)=VRec(:,ii)+V(Irecord);    


    % Euler update to V
    V=V+(dt/taum)*(Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT));
    V=max(V,Vlb);
    w=w-(dt/tauw)*w;

    % Find which neurons spiked
    Ispike=find(V>=Vth);    

    % Euler update to synaptic currents
    Ie=Ie-dt*Ie/taue;
    Ii=Ii-dt*Ii/taui;
    Ix=Ix-dt*Ix/taux;    

    % If there are spikes
    if(~isempty(Ispike))

        % Store spike times and neuron indices
        if(nspike+numel(Ispike)<=maxns)
            s(1,nspike+1:nspike+numel(Ispike))=time(i);
            s(2,nspike+1:nspike+numel(Ispike))=Ispike;
        else
            TooManySpikes=1;
            break;
        end

        % Reset mem pot.
        V(Ispike)=Vre;
        w(Ispike)=w(Ispike)+b;
        
        % Update synaptic currents
        Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
        Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            

        % Update cumulative number of spikes
        nspike=nspike+numel(Ispike);
    end

    % Propogate ffwd spikes
    while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
        jpre=sx(2,iXspike);
        Ix=Ix+Jx(:,jpre)/taux;
        iXspike=iXspike+1;
    end

end
s=s(:,1:nspike); % Get rid of padding in s
end    
if(TooManySpikes)
    warning('\nMax number spikes exceeded, simulation terminated at time t=%1.1f.\n',dt*i)
end
IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
IiRec=IiRec/nBinsRecord;
IxRec=IxRec/nBinsRecord;
VRec=VRec/nBinsRecord;

dtRate=20;
rateTime=dtRate:dtRate:T;
re1SimTime=hist(s(1,s(2,:)<=Ns(1)),rateTime)/(Ns(1)*dtRate);
re2SimTime=hist(s(1,s(2,:)>Ns(1) & s(2,:)<=Ne),rateTime)/(Ns(2)*dtRate);
riSimTime=hist(s(1,s(2,:)>Ne),rateTime)/(Ni*dtRate);

re1Sim0=zeros(nstim,1);
re2Sim0=zeros(nstim,1);
riSim0=zeros(nstim,1);
rTh=zeros(3,nstim);
rThTime=zeros(3,numel(rateTime));
for jj=1:nstim
    rTh(:,jj)=-inv(W)*Wx*[rx1(jj); rx2(jj)];
    I=find(rTh(:,jj)>0);
    re1Sim0(jj)=mean(re1SimTime(mod(IntDivide(rateTime,T0)-1,nstim)==jj-1));
    re2Sim0(jj)=mean(re2SimTime(mod(IntDivide(rateTime,T0)-1,nstim)==jj-1));
    riSim0(jj)=mean(riSimTime(mod(IntDivide(rateTime,T0)-1,nstim)==jj-1));
for ii=1:nreps
    i1=round(1+(T0*(ii-1)*nstim+T0*(jj-1))/dtRate);
    i2=round((T0+T0*(ii-1)*nstim+T0*(jj-1))/dtRate);
    rThTime(:,i1:i2)=repmat(rTh(:,jj),1,i2-i1+1);
end
end
re1ThTime=rThTime(1,:);
re2ThTime=rThTime(2,:);
riThTime=rThTime(3,:);

re1Th0=rTh(1,:);
re2Th0=rTh(2,:);
riTh0=rTh(3,:);

e1EXinput=mean(IeRec(1:Ns(1),:)+IxRec(1:Ns(1),:));
e1Iinput=mean(IiRec(1:Ns(1),:));


e2EXinput=mean(IeRec(Ns(1)+1:Ne,:)+IxRec(Ns(1)+1:Ne,:));
e2Iinput=mean(IiRec(Ns(1)+1:Ne,:));


jj=1;
while(nnz(s(2,:)==jj)<10 || nnz(s(2,:)==jj)>15)
    jj=jj+1;
end

kcV=round(1/dtRecord);
Vplot=coarsify(VRec(jj,:),kcV);
Vplot(round(s(1,s(2,:)==jj)/(kcV*dtRecord)))=0;
plot(Vplot)

ttotal=toc(tstart)

nspikeplot=200;
se1plot=s(:,s(2,:)<=nspikeplot);
se2plot=s(:,s(2,:)<=nspikeplot+Ns(1) & s(2,:)>Ns(1));
siplot=s(:,s(2,:)<=nspikeplot+Ne & s(2,:)>Ne);
se2plot(2,:)=se2plot(2,:)-Ns(1);
siplot(2,:)=siplot(2,:)-Ne;

sx1plot=sx(:,sx(2,:)<=nspikeplot);
sx2plot=sx(:,sx(2,:)<=nspikeplot+Nxs(1) & sx(2,:)>Nxs(1));

clear IxRec IeRec IiRec VRec s st sx J Jee Jei Jie Jii Jx;
save Fig1C.mat

%% Load data and make plots

load Fig1C.mat


lw=2;
fs=28;
mrkrsize=1;
e1clr=[.75 .25 .25];
e2clr=[.85 .65 .65];
iclr=[.25 .25 .85];


Eclr=[.6 .1 .1];
Iclr=[.1 .1 .6];
Tclr=[0 0 0];


figure
plot(sx1plot(1,:)/1000,sx1plot(2,:)+4*nspikeplot,'k.','MarkerSize',mrkrsize)
hold on
plot(sx2plot(1,:)/1000,sx2plot(2,:)+3*nspikeplot-Nxs(1),'k.','MarkerSize',mrkrsize)
plot(se1plot(1,:)/1000,se1plot(2,:)+2*nspikeplot,'k.','MarkerSize',mrkrsize)
hold on
plot(se2plot(1,:)/1000,se2plot(2,:)+nspikeplot,'k.','MarkerSize',mrkrsize)
plot(siplot(1,:)/1000,siplot(2,:),'k.','MarkerSize',mrkrsize)
set(gcf,'Position',[153   516   942*.31   217*1.5]*1.28)
set(gca,'XTick',[T0:T0:T]/1000)
set(gca,'YTick',[nspikeplot:nspikeplot:5*nspikeplot])
set(gca,'YTickLabels',[])
set(gca,'XTickLabels',[])
set(gcf,'Color',[1 1 1])
box on
set(gca,'LineWidth',2)
axis([0 T/1000 1 5*nspikeplot])

figure
plot(rateTime(2:end-1)/1000,1000*re1SimTime(2:end-1),'Color',e1clr,'LineWidth',lw)
hold on
plot(rateTime(2:end-1)/1000,1000*re2SimTime(2:end-1),'Color',e2clr,'LineWidth',lw)
plot(rateTime(2:end-1)/1000,1000*riSimTime(2:end-1),'Color',iclr,'LineWidth',lw)
stairs(rateTime/1000,1000*re1ThTime,'--','Color',e1clr,'LineWidth',lw)
stairs(rateTime/1000,1000*re2ThTime,'--','Color',e2clr,'LineWidth',lw)
stairs(rateTime/1000,1000*riThTime,'--','Color',iclr,'LineWidth',lw)
xlabel('time (s)')
ylabel('rate (Hz)')
axis tight
axis([0 Inf 0 Inf])
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gca,'xtick',0:1:T)
set(gcf,'Position',[153   516   942*.31   217]*1.28)


figure
load AdExRheobase.mat
kc=round(10/dtRecord);
plot(coarsify(timeRecord,kc)/1000,coarsify(e1EXinput,kc)/rheobase,'Color',Eclr,'LineWidth',lw)
hold on
plot(coarsify(timeRecord,kc)/1000,coarsify(e1Iinput,kc)/rheobase,'Color',Iclr,'LineWidth',lw)
plot(coarsify(timeRecord,kc)/1000,coarsify(e1EXinput+e1Iinput,kc)/rheobase,'Color',Tclr,'LineWidth',lw)
xlabel('time (s)')
ylabel('input to e1')
axis tight
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gca,'xtick',0:1:T)
set(gcf,'Position',[153   516   942*.31   217]*1.28)

figure
load AdExRheobase.mat
kc=round(10/dtRecord);
plot(coarsify(timeRecord,kc)/1000,coarsify(e2EXinput,kc)/rheobase,'Color',Eclr,'LineWidth',lw)
hold on
plot(coarsify(timeRecord,kc)/1000,coarsify(e2Iinput,kc)/rheobase,'Color',Iclr,'LineWidth',lw)
plot(coarsify(timeRecord,kc)/1000,coarsify(e2EXinput+e1Iinput,kc)/rheobase,'Color',Tclr,'LineWidth',lw)
xlabel('time (s)')
ylabel('input to e2')
axis tight
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gca,'xtick',0:1:T)
set(gcf,'Position',[153   516   942*.31   217]*1.28)

figure
plot(coarsify(timeRecord,kcV)/1000,Vplot,'Color',[.35 .35 .35],'LineWidth',1)
xlabel('time (s)')
ylabel('V')
axis tight
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gca,'xtick',0:1:T)
set(gcf,'Position',[153   516   942*.31   217]*1.28)


