
clear
close all

path(path,'./ReadMNIST/')

tstart=tic;

% Number of neurons in each pop
Ne=8000/2%3;
Ni=2000/2%3;
Nx=2000/2%3;
N=Ne+Ni;

% Mean synaptic weights
Jm=15*[25 -150;112.5 -250]/sqrt(N);
Jxm=15*[180; 135]/sqrt(N);

% Connection probabilities
P=[.1 .1; .1 .1];
Px=[.1; .1];

% In-degrees
K=[Ne Ni;Ne Ni].*P;
Kx=[Nx;Nx].*Px;

% Coupling strength coefficient in mV/kHz
JKbar=mean(mean([abs(Jm).*K abs(Jxm).*Kx]));

% Mean-field connectivity (dimensionless)
W=Jm.*K/JKbar;
Wx=Jxm.*Kx/JKbar;

% Neuron parameters
taum=15;
EL=-72;
Vth=0;
Vre=-72;
Vlb=-85;
DeltaT=1;
VT=-55;
tauw=200;
a=0;
b=.75;

% Synaptic timescales
taue=8;
taui=4;
taux=10;

Xbar=JKbar*Wx*[10/1000];


%%%%%
% First train recurrent weights with ISP
%%%%%

% Sim time and time step
T=1e3;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Strength of MNIST input
sigma=20;

temp=floor(400*((1:Ne)-1)/Ne)+1;
[eLocsX,eLocsY]=ind2sub([20 20],temp);

temp=1:400;
[xLocsX,xLocsY]=ind2sub([20 20],temp);

ImProjection=zeros(N,400);
for j=1:400
    I=find(eLocsX==xLocsX(j) & eLocsY==xLocsY(j));
    ImProjection(I,j)=sigma;

end


% Generate connectivity matrices
tic
J=[(Jm(1,1)*binornd(1,P(1,1),Ne,Ne)) ...
   (Jm(1,2)*binornd(1,P(1,2),Ne,Ni)); ...
   (Jm(2,1)*binornd(1,P(2,1),Ni,Ne)) ...
   (Jm(2,2)*binornd(1,P(2,2),Ni,Ni))];  
tGen=toc
disp(sprintf('\nTime to generate connections: %.2f sec',tGen))

% Random initial voltages
V0=rand(N,1)*(VT-Vre)+Vre;

% Maximum number of spikes for all neurons
% in simulation. Make it 50Hz across all neurons
% If there are more spikes, the simulation will
% terminate
maxns=ceil(.05*N*T);

% Integer division function
IntDivide=@(n,k)(floor((n-1)/k)+1);

% Plasticity params
eta=.03; % Learning rate 
tauSTDP=200;
rho0=0.005; % Target rate
alpha=2*rho0*tauSTDP;

% Number of trials to train weights
% with ISP
nISPtraining=100;

% Indices of neurons from which to record currents, voltages
Irecord=1:Ne;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=T;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);


MeanIeISPtrain=zeros(nISPtraining,numrecord);
MeanIxISPtrain=zeros(nISPtraining,numrecord);
MeanIiISPtrain=zeros(nISPtraining,numrecord);
rSimISPtrain=zeros(nISPtraining,N);
[ISPtrainImgs, ISPtrainLabels] = readMNIST('train-images-idx3-ubyte', 'train-labels-idx1-ubyte', nISPtraining, 0);
ISPtrainImgs=reshape(ISPtrainImgs,400,nISPtraining);


V=V0;
Ie=zeros(N,1);
Ii=zeros(N,1);
Ix=zeros(N,1);
w=zeros(N,1);
x=zeros(N,1);

Ix0=zeros(N,1);
Ix0(1:Ne)=Xbar(1);
Ix0(Ne+1:N)=Xbar(2);
for ijk=1:nISPtraining

    [ijk nISPtraining]
    
    Ix=Ix0+ImProjection*ISPtrainImgs(:,ijk);
     

    % Initialize stuff
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    % Euler solver
    tic
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        %Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))


            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            


            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end


            % If there is plasticity
            if(eta~=0)
                % Update synaptic weights according to plasticity rules
                % I to E after an I spike    
                J(1:Ne,Ispike(Ispike>Ne))=J(1:Ne,Ispike(Ispike>Ne))+ ... 
                    -repmat(eta*(x(1:Ne)-alpha),1,nnz(Ispike>Ne)).*(J(1:Ne,Ispike(Ispike>Ne))~=0);
                % E to I after an E spike
                J(Ispike(Ispike<=Ne),Ne+1:N)=J(Ispike(Ispike<=Ne),Ne+1:N)+ ... 
                    -repmat(eta*x(Ne+1:N)',nnz(Ispike<=Ne),1).*(J(Ispike(Ispike<=Ne),Ne+1:N)~=0);
            end

            % Update rate estimates for plasticity rules
            x(Ispike)=x(Ispike)+1;


            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);



        end


        % Update time-dependent firing rates for plasticity
        x(1:Ne)=x(1:Ne)-dt*x(1:Ne)/tauSTDP;
        x(Ne+1:end)=x(Ne+1:end)-dt*x(Ne+1:end)/tauSTDP;


    end
    
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    rSimISPtrain(ijk,:)=hist(s(2,s(2,:)>0),1:N)/T;
    MeanIeISPtrain(ijk,:)=IeRec(:,1);
    MeanIiISPtrain(ijk,:)=IiRec(:,1);
    MeanIxISPtrain(ijk,:)=IxRec(:,1);        

end

%%%%%%
% Now generate rates with which we will train readout weights
%%%%%%


% Sim time and time step
T=1e4;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Indices of neurons from which to record currents, voltages
Irecord=1:N;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=T;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

nReadoutTraining=2000;


MeanIeReadoutTrain=zeros(nReadoutTraining,numrecord);
MeanIxReadoutTrain=zeros(nReadoutTraining,numrecord);
MeanIiReadoutTrain=zeros(nReadoutTraining,numrecord);
rSimReadoutTrain=zeros(nReadoutTraining,N);
[ReadoutTrainImgs, ReadoutTrainLabels] = readMNIST('train-images-idx3-ubyte', 'train-labels-idx1-ubyte', nReadoutTraining, nISPtraining+1);
ReadoutTrainImgs=reshape(ReadoutTrainImgs,400,nReadoutTraining);

maxns=ceil(.05*N*T);

Ix0=zeros(N,1);
Ix0(1:Ne)=Xbar(1);
Ix0(Ne+1:N)=Xbar(2);
sRec={};
t0=tic;
parfor ijk=1:nReadoutTraining

    [ijk nReadoutTraining]
    
    Ix=Ix0+ImProjection*ReadoutTrainImgs(:,ijk);

    % Initialize stuff
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    % Euler solver
    tic
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    V=rand(N,1)*(VT-Vre)+Vre;
    Ie=zeros(N,1);
    Ii=zeros(N,1);
    %Ix=zeros(N,1);
    w=zeros(N,1);


    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        %Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))


            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            


            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end


            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);



        end



    end
    
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    rSimReadoutTrain(ijk,:)=hist(s(2,s(2,:)>0),1:N)/T;
    MeanIeReadoutTrain(ijk,:)=IeRec(:,1);
    MeanIiReadoutTrain(ijk,:)=IiRec(:,1);
    MeanIxReadoutTrain(ijk,:)=IxRec(:,1);        

    
    
end




% Random subset of rates
nClasses = 10;
R = 1:numel(ReadoutTrainLabels);
Target = zeros(numel(ReadoutTrainLabels),nClasses);
Target(sub2ind(size(Target),R,ReadoutTrainLabels'+1)) = 1;
ncells=[1 10 20 50 100:100:1800 2000];
LinModel_1_MisclassRate=zeros(size(ncells));
for j=1:numel(ncells)
    [j numel(ncells)]
    whichcells=randi(4000,ncells(j),1);


    LinModel_1 = pinv([ones(nReadoutTraining,1) rSimReadoutTrain(:,whichcells)])*Target;

    LinModel_1_Scores = [ones(nReadoutTraining,1) rSimReadoutTrain(:,whichcells)]*LinModel_1;
    [~,LinModel_1_YHat] = max(LinModel_1_Scores');
    LinModel_1_YHat = LinModel_1_YHat - 1;
    LinModel_1_MisclassRate(j) = 1 - sum(LinModel_1_YHat==ReadoutTrainLabels')/nReadoutTraining;

end


% Random projection of rates
ncells=[1 10 20 50 100:100:1800 2000];
LinModel_2_MisclassRate=zeros(size(ncells));
for j=1:numel(ncells)
    [j numel(ncells)]
    X=(randn(ncells(j),Ne)*rSimReadoutTrain(:,1:Ne)')';
    
    LinModel_2 = pinv([ones(nReadoutTraining,1) X])*Target;

    LinModel_2_Scores = [ones(nReadoutTraining,1) X]*LinModel_2;
    [~,LinModel_2_YHat] = max(LinModel_2_Scores');
    LinModel_2_YHat = LinModel_2_YHat - 1;
    LinModel_2_MisclassRate(j) = 1 - sum(LinModel_2_YHat==ReadoutTrainLabels')/nReadoutTraining;

end


% Pixel Space
FlatImgs = reshape(ReadoutTrainImgs,[20*20,nReadoutTraining]);

LinModelPix = pinv([ones(nReadoutTraining,1) FlatImgs'])*Target;
LinModelPix_Scores = [ones(nReadoutTraining,1) FlatImgs']*LinModelPix;
[~,LinModelPix_YHat] = max(LinModelPix_Scores');
LinModelPix_YHat = LinModelPix_YHat - 1;
LinModelPix_MisclassRate = 1 - sum(LinModelPix_YHat==ReadoutTrainLabels')/nReadoutTraining;


% Random projection of pixel Space
LinModelX_MisclassRate=zeros(size(ncells));
for j=1:numel(ncells)
    [j numel(ncells)]
    X=randn(ncells(j),400)*FlatImgs;

    LinModelX = pinv([ones(nReadoutTraining,1) X'])*Target;
    LinModelX_Scores = [ones(nReadoutTraining,1) X']*LinModelX;
    [~,LinModelX_YHat] = max(LinModelX_Scores');
    LinModelX_YHat = LinModelX_YHat - 1;
    LinModelX_MisclassRate(j) = 1 - sum(LinModelX_YHat==ReadoutTrainLabels')/nReadoutTraining;

end

% Train positive readout weights using a supervised Hebbian-like rule
U=zeros(10,Ne);
% Train Wr using a simple supervised Hebbian rule
for j=1:10
   U(j,:)=sum(rSimReadoutTrain(ReadoutTrainLabels==j-1,1:Ne)); 
end

% Normalize rows and columns of W
for j=1:10
    U(j,:)=U(j,:)/norm(U(j,:));
end
for j=1:Ne
    U(:,j)=U(:,j)/norm(U(:,j));
end

% Compute training error
GuessLabelsTrainHebb=zeros(nReadoutTraining,1);
for j=1:nReadoutTraining
    [~,temp]=max(rSimReadoutTrain(j,1:Ne)*U');
    GuessLabelsTrainHebb(j)=temp-1;
end
Hebb_MisclassRate=1-nnz(ReadoutTrainLabels==GuessLabelsTrainHebb)/nReadoutTraining;



%%%%%%
% Now simulate a spiking net with readout 
%%%%%%


% Sim time and time step
T=2e3;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Indices of neurons from which to record currents, voltages
Irecord=1:N;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=T;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

nTesting=200;


maxns=ceil(.05*N*T);

% Simulate first layer
MeanIeTest=zeros(nTesting,numrecord);
MeanIxTest=zeros(nTesting,numrecord);
MeanIiTest=zeros(nTesting,numrecord);
rSimTest=zeros(nTesting,N);
[TestImgs, TestLabels] = readMNIST('train-images-idx3-ubyte', 'train-labels-idx1-ubyte', nTesting, nReadoutTraining+nISPtraining+1);
TestImgs=reshape(TestImgs,400,nTesting);

Ix0=zeros(N,1);
Ix0(1:Ne)=Xbar(1);
Ix0(Ne+1:N)=Xbar(2);
sFirstLayer=cell(nTesting,1);
t0=tic;
parfor ijk=1:nTesting

    [ijk nTesting]
    
    Ix=Ix0+ImProjection*TestImgs(:,ijk);

    % Initialize stuff
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    % Euler solver
    tic
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    V=rand(N,1)*(VT-Vre)+Vre;
    Ie=zeros(N,1);
    Ii=zeros(N,1);
    %Ix=zeros(N,1);
    w=zeros(N,1);


    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        %Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))


            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            


            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end


            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);



        end



    end
    
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    rSimTest(ijk,:)=hist(s(2,s(2,:)>0),1:N)/T;
    MeanIeTest(ijk,:)=IeRec(:,1);
    MeanIiTest(ijk,:)=IiRec(:,1);
    MeanIxTest(ijk,:)=IxRec(:,1);        


    sFirstLayer{ijk}=s(:,s(2,:)>0);
    
end


% Simulate next layer
Nx=Ne; % External pop is now excitatory pop of first layer, with Ne cells

% 10 exc pops, 1 inh
Jm=15*[10*25*ones(10,10) -150*ones(10,1);10*112.5*ones(1,10) -250*ones(1,1)]/sqrt(N);
P=.1*[eye(10,10) ones(10,1); ones(1,10) ones(1,1)];
Xbar=[Xbar(1)*ones(10,1); Xbar(2)];%[.036*ones(10,1);.027]*sqrt(N); % Baseline ext input about the same as before


% Generate connectivity matrices
tic
J=zeros(N,N);
Jx=zeros(N,Nx);
Ix0=zeros(N,1);
sigma=6; % Amount by which to scale ffwd weights
Xproj=zeros(N,10);
for j=1:10
    J((j-1)*Ne/10+1:j*Ne/10,(j-1)*Ne/10+1:j*Ne/10)=Jm(j,j)*binornd(1,P(j,j),Ne/10,Ne/10);
    
    J(Ne+1:N,(j-1)*Ne/10+1:j*Ne/10)=Jm(11,j)*binornd(1,P(11,j),Ni,Ne/10);
    
    J((j-1)*Ne/10+1:j*Ne/10,Ne+1:N)=Jm(j,11)*binornd(1,P(j,11),Ne/10,Ni);
    
    Ix0((j-1)*Ne/10+1:j*Ne/10)=Xbar(j);
    
    Jx((j-1)*Ne/10+1:j*Ne/10,1:Nx)=repmat(sigma*U(j,:),400,1);
    
    Xproj((j-1)*Ne/10+1:j*Ne/10,j)=1;

end
J(Ne+1:N,Ne+1:N)=Jm(11,11)*binornd(1,P(11,11),Ni,Ni);
Ix0(Ne+1:N)=Xbar(11);
tGen=toc
disp(sprintf('\nTime to generate connections: %.2f sec',tGen))


MeanIeSecondLayer=zeros(nTesting,numrecord);
MeanIxSecondLayer=zeros(nTesting,numrecord);
MeanIiSecondLayer=zeros(nTesting,numrecord);
MeanPopRates=zeros(nTesting,10);
MeanPopIx=zeros(nTesting,10);
rSimSecondLayer=zeros(nTesting,N);
GuessR=zeros(nTesting,1);
GuessX=zeros(nTesting,1);
CorrectR=zeros(nTesting,1);
CorrectX=zeros(nTesting,1);
sSecondLayer=cell(nTesting,1);
t0=tic;
parfor ijk=1:nTesting

    [ijk nTesting]
    
    % External pop to this layer
    % is exc pop from first layer
    sx=sFirstLayer{ijk};
    sx=sx(:,sx(2,:)<=Nx);
    [~,I]=sort(sx(1,:));
    sx=sx(:,I);
    nspikeX=size(sx,2);  

    % Initialize stuff
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    % Euler solver
    tic
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    V=rand(N,1)*(VT-Vre)+Vre;
    Ie=zeros(N,1);
    Ii=zeros(N,1);
    Ix=zeros(N,1);
    w=zeros(N,1);


    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(Ie+Ii+Ix+Ix0+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))


            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            


            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end


            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);

        end


        % Propogate ffwd spikes
        while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
            jpre=sx(2,iXspike);
            Ix=Ix+Jx(:,jpre)/taux;
            iXspike=iXspike+1;
        end


    end
    
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    rSimSecondLayer(ijk,:)=hist(s(2,s(2,:)>0 & s(1,:)>Tburn),1:N)/(T-Tburn);
    MeanIeSecondLayer(ijk,:)=IeRec(:,1);
    MeanIiSecondLayer(ijk,:)=IiRec(:,1);
    MeanIxSecondLayer(ijk,:)=IxRec(:,1);        

    temp=rSimSecondLayer(ijk,:);
    MeanPopRates(ijk,:)=1000*temp(1:Ne)*Xproj(1:Ne,:)/(Ne/10);
    MeanPopIx(ijk,:)=IxRec(1:Ne)'*Xproj(1:Ne,:)/(Ne/10);
    
    [~,temp]=max(MeanPopRates(ijk,:));
    GuessR(ijk)=temp(1)-1;
    CorrectR(ijk)=(GuessR(ijk)==TestLabels(ijk));
    
    [~,temp]=max(MeanPopIx(ijk,:));
    GuessX(ijk)=temp(1)-1;
    
    MeanPopRates(ijk,:)
    GuessR(ijk)
    GuessX(ijk)
    TestLabels(ijk)
    CorrectX(ijk)=(GuessX(ijk)==TestLabels(ijk));
    
    
    sSecondLayer{ijk}=s(:,s(2,:)>0);
    
end


ttotal=toc(tstart)
clear X s J Jx sFirstLayer ImProjection;

% Get spike times for plot
ntrialsPlot=10;
ncellsPlot=50;
sPlot=[];
for ijk=1:ntrialsPlot
for j=1:10
    stemp=sSecondLayer{ijk};
    stemp=stemp(:,stemp(2,:)>=(Ne/10)*(j-1) & stemp(2,:)<=(Ne/10)*(j-1)+ncellsPlot);
    stemp(1,:)=(stemp(1,:)+(ijk-1)*T)/1000;
    stemp(2,:)=stemp(2,:)-(j-1)*(Ne/10)+(j-1)*ncellsPlot;
    sPlot=[sPlot stemp];
end
end

clear sSecondLayer stemp;



% Perform PCA and ISOMAP analysis
ndims=100;
ncells0=Ne;
ntrials=2000;
options.dims=1:ndims;
x=rSimReadoutTrain(1:ntrials,1:ncells0);
D=sqdist(x',x');
[Y, RRR, E] = IsoMap(D, 'epsilon',6,options);
[COEFF, SCORE, LATENT, TSQUARED, EXPLAINED] = pca(x);

% Train optimal linear model on training data
LinModel_1 = pinv([ones(nReadoutTraining,1) rSimReadoutTrain(:,1:Ne)])*Target;

% Run on untrained "test" data to generate predicted classes
LinModel_1_TestScores = [ones(nTesting,1) rSimTest(:,1:Ne)]*LinModel_1;
[~,LinModel_1_TestYHat] = max(LinModel_1_TestScores');
LinModel_1_TestYHat = LinModel_1_TestYHat - 1;

% Get misclassification rate
LinModel_1_TestMisclassRate = 1 - sum(LinModel_1_TestYHat==TestLabels')/nTesting
1-LinModel_1_TestMisclassRate



% Do the same for pixel Space
FlatImgsTest = reshape(TestImgs,[20*20,nTesting]);
LinModelPix_TestScores = [ones(nTesting,1) FlatImgsTest']*LinModelPix;
[~,LinModelPix_TestYHat] = max(LinModelPix_TestScores');
LinModelPix_TestYHat = LinModelPix_TestYHat - 1;
LinModelPix_TestMisclassRate = 1 - sum(LinModelPix_TestYHat==TestLabels')/nTesting
1-LinModelPix_TestMisclassRate



MNImPlot=reshape(TestImgs(:,1:ntrialsPlot),[20 20*ntrialsPlot]);
MNImPlot(:,20:20:19*ntrialsPlot)=1;

clear TestImgs FlatImgs MeanIeReadoutTrain MeanIiReadoutTrain MeanIxReadoutTrain;
clear ReadoutTrainImgs rSimReadoutTrain whichcells Y;
clear COEFF SCORE LATENT TSQUARED x D E;
clear rSimISPtrain rSimSecondLayer rSimTest MeanIeISPtrain MeanIeSecondLayer;
clear MeanIeTest MeanIiISPtrain MeanIiSecondLayer MeanIiTest MeanIxISPtrain;
clear MeanIxSecondLayer MeanIxTest;
save Fig4.mat


%% Load data and make plots

load Fig4.mat

lw=2;
fs=20;

figure
plot(sPlot(1,:),sPlot(2,:),'k.')
hold on
for j=1:9
    plot([0 ntrialsPlot*T/1000],j*ncellsPlot*[1 1],'k')    
end
set(gca,'YTick',(0:9)*ncellsPlot+ncellsPlot/2+2)
set(gca,'YTickLabels',{'e0','e1','e2','e3','e4','e5','e6','e7','e8','e9'})
set(gca,'XTick',0:4:20)
xlabel('time (s)')
set(gcf,'Position',[153   516   650 404])
set(gcf,'Color',[1 1 1])
box on
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)

figure
imagesc(MNImPlot)
colormap gray
set(gca,'YTick',[])
set(gca,'XTick',[])


figure
plot(ncells,100*LinModel_1_MisclassRate,'LineWidth',lw,'Color',[.8 .2 .2])
hold on
plot(ncells,100*LinModelX_MisclassRate,'--','LineWidth',lw,'Color',[.7 .7 .7])
plot(400,100*LinModelPix_MisclassRate,'k*','MarkerSize',15)
xlabel('num. cells sampled')
ylabel('percent misclassified')
axis tight
axis([-15 Inf -1 100])
set(gca,'XTick',[1 1000 2000])
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gcf,'Position',[153   516   440*1  300]*.8)




