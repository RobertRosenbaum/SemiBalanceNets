
clear
close all

tstart=tic;

% Number of neurons in each pop
Ne=8000*3;
Ni=2000*3;
Nx=2000*3;
N=Ne+Ni;

% Number of neurons in each sub-pop
Ne1=round(Ne/2);
Ne2=Ne-Ne1;
Nx1=round(Nx/2);

Ns=[Ne1 Ne2 Ni];
N=sum(Ns);
Nxs=[.5*Nx .5*Nx];
Nx=sum(Nxs); 

% Mean synaptic weights
Jm=15*[25 25 -150;25 25 -150;112.5 112.5 -250]/sqrt(N);
Jxm=15*[180 180;180 180; 135 135]/sqrt(N);

% Connection probabilities
P=[.05 .15 .1;.15 .05 .1; .1 .1 .1];
Px=[.08 .1;.1 .1; .1 .1];

% In-degrees
K=repmat(Ns,numel(Ns),1).*P;
Kx=repmat(Nxs,numel(Ns),1).*Px;

% Coupling strength coefficient in mV/kHz
JKbar=mean(mean([abs(Jm).*K abs(Jxm).*Kx]));

% Mean-field connectivity (dimensionless)
W=Jm.*K/JKbar;
Wx=Jxm.*Kx/JKbar;

% Neuron parameters
taum=15;
EL=-72;
Vth=0;
Vre=-72;
Vlb=-85;
DeltaT=1;
VT=-55;
tauw=200;
a=0;
b=.75;

% Synaptic timescales
taue=8;
taui=4;
taux=10;


% Sim time and time step
T=5e3;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Indices of neurons from which to record currents, voltages
Irecord=1:N;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=500;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

% Rate of external population
[rx1s,rx2s]=meshgrid((0:2:25)/1000,(0:2:25)/1000);

% Generate connectivity matrices
% Maybe it would be better to do this in a loop
tic
J=sparse([(Jm(1,1)*binornd(1,P(1,1),Ns(1),Ns(1))) ...
   (Jm(1,2)*binornd(1,P(1,2),Ns(1),Ns(2))) ...
   (Jm(1,3)*binornd(1,P(1,3),Ns(1),Ns(3))); ...
   (Jm(2,1)*binornd(1,P(2,1),Ns(2),Ns(1))) ...
   (Jm(2,2)*binornd(1,P(2,2),Ns(2),Ns(2))) ...
   (Jm(2,3)*binornd(1,P(2,3),Ns(2),Ns(3))); ...
   (Jm(3,1)*binornd(1,P(3,1),Ns(3),Ns(1))) ...
   (Jm(3,2)*binornd(1,P(3,2),Ns(3),Ns(2))) ...
   (Jm(3,3)*binornd(1,P(3,3),Ns(3),Ns(3)));]);

Jx=sparse([(Jxm(1,1)*binornd(1,Px(1,1),Ns(1),Nxs(1))) ...
    (Jxm(1,2)*binornd(1,Px(1,2),Ns(1),Nxs(2))); ...
    (Jxm(2,1)*binornd(1,Px(2,1),Ns(2),Nxs(1))) ...
    (Jxm(2,2)*binornd(1,Px(2,2),Ns(2),Nxs(2))); ...
    (Jxm(3,1)*binornd(1,Px(3,1),Ns(3),Nxs(1))) ...
    (Jxm(3,2)*binornd(1,Px(3,2),Ns(3),Nxs(2)));]);    
tGen=toc
disp(sprintf('\nTime to generate connections: %.2f sec',tGen))

parfor iii=1:numel(rx2s)

    [iii numel(rx2s)]
       
       
    rx2=rx2s(iii);
    rx1=rx1s(iii);
    
    % Make Poisson spike times for ffwd layer    
    nspikeX1=poissrnd(Nxs(1)*rx1*T);
    nspikeX2=poissrnd(Nxs(2)*rx2*T);
    nspikeX=nspikeX1+nspikeX2;
    sx=zeros(2,nspikeX);    
    sx(1,1:nspikeX1)=rand(nspikeX1,1)*T;
    sx(1,nspikeX1+1:nspikeX)=rand(nspikeX2,1)*T;
    sx(2,1:nspikeX1)=randi(Nxs(1),1,nspikeX1);
    sx(2,nspikeX1+1:nspikeX)=Nxs(1)+randi(Nxs(2),1,nspikeX2);
    [st,I]=sort(sx(1,:));
    sx(2,:)=sx(2,I);
    sx(1,:)=st;

    % Random initial voltages
    V0=rand(N,1)*(VT-Vre)+Vre;

    % Maximum number of spikes for all neurons
    % in simulation. Make it 50Hz across all neurons
    % If there are more spikes, the simulation will
    % terminate
    maxns=ceil(.05*N*T);

    % Integer division function
    IntDivide=@(n,k)(floor((n-1)/k)+1);

    % Initialize stuff
    V=V0;
    w=zeros(N,1);
    Ie=zeros(N,1);
    Ii=zeros(N,1);
    Ix=zeros(N,1);
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;

    % Euler solver
    tic
    if(nspikeX==0)
        s=zeros(2,0);
    else
    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT));
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))

            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end

            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            

            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);
        end

        % Propogate ffwd spikes
        while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
            jpre=sx(2,iXspike);
            Ix=Ix+Jx(:,jpre)/taux;
            iXspike=iXspike+1;
        end

    end
    s=s(:,1:nspike); % Get rid of padding in s
    end    
    if(TooManySpikes)
        warning('\nMax number spikes exceeded, simulation terminated at time t=%1.1f.\n',dt*i)
    end
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    reSim(iii)=nnz(s(2,:)<=Ne & s(1,:)>Tburn)/((T-Tburn)*Ne);
    re1Sim(iii)=nnz(s(2,:)<=Ne1 & s(1,:)>Tburn)/((T-Tburn)*Ne2);
    re2Sim(iii)=nnz(s(2,:)>Ne1 & s(2,:)<=Ne & s(1,:)>Tburn)/((T-Tburn)*Ne1);
    riSim(iii)=nnz(s(2,:)>Ne & s(1,:)>Tburn)/((T-Tburn)*Ni);

    rsim=[re1Sim(iii);re2Sim(iii);riSim(iii)];
  
    rx=[rx1;rx2];
    rBal=-pinv(W)*Wx*rx; 

    re1Bal(iii)=rBal(1);
    re2Bal(iii)=rBal(2);
    riBal(iii)=rBal(3);

    Xbar=Wx*rx*sqrt(N);

    XbarThE1(iii)=Xbar(1);
    XbarThE2(iii)=Xbar(2);
    XbarThI(iii)=Xbar(3);
    
    XbarSimE1(iii)=mean(mean(IxRec(1:Ns(1),2:end)));
    XbarSimE2(iii)=mean(mean(IxRec(Ns(1)+1:Ne,2:end)));
    XbarSimI(iii)=mean(mean(IxRec(Ne+1:N,2:end)));

    RecBarTh=W*rsim*sqrt(N);
    RecBarE1Th(iii)=RecBarTh(1);
    RecBarE2Th(iii)=RecBarTh(2);
    RecBarITh(iii)=RecBarTh(3);
    
    RecBarE1Sim(iii)=mean(mean(IeRec(1:Ns(1),2:end)+IiRec(1:Ns(1),2:end)));
    RecBarE2Sim(iii)=mean(mean(IeRec(Ns(1)+1:Ne,2:end)+IiRec(Ns(1)+1:Ne,2:end)));
    RecBarISim(iii)=mean(mean(IeRec(Ne+1:N,2:end)+IiRec(Ne+1:N,2:end)));

    TotalBarE1Sim(iii)=mean(mean(IeRec(1:Ns(1),2:end)+IiRec(1:Ns(1),2:end)+IxRec(1:Ns(1),2:end)));
    TotalBarE2Sim(iii)=mean(mean(IeRec(Ns(1)+1:Ne,2:end)+IiRec(Ns(1)+1:Ne,2:end)+IxRec(Ns(1)+1:Ne,2:end)));
    TotalBarISim(iii)=mean(mean(IeRec(Ne:N,2:end)+IiRec(Ne:N,2:end)+IxRec(Ne:N,2:end)));

    
    rSemiBal=zeros(size(rBal));
    I=find(rBal>0);
    rSemiBal(I)=-pinv(W(I,I))*Wx(I,:)*rx;
        
    re1SemiBal(iii)=rSemiBal(1);
    re2SemiBal(iii)=rSemiBal(2);
    riSemiBal(iii)=rSemiBal(3);
    
    Ws{iii}=W;
    Wxs{iii}=Wx;
    rxs{iii}=rx;
    Xbars{iii}=Xbar;
    rThs{iii}=rBal;

end
ttotal=toc(tstart)


re1Sim=reshape(re1Sim,size(rx1s));
re2Sim=reshape(re2Sim,size(rx1s));
riSim=reshape(riSim,size(rx1s));

re1Bal=reshape(re1Bal,size(rx1s));
re2Bal=reshape(re2Bal,size(rx1s));
riBal=reshape(riBal,size(rx1s));

re1SemiBal=reshape(re1SemiBal,size(rx1s));
re2SemiBal=reshape(re2SemiBal,size(rx1s));
riSemiBal=reshape(riSemiBal,size(rx1s));

clear s st sx J Jee Jei Jie Jii Jx;
save Fig1D.mat

%% Load data and make plot
load Fig1D.mat


re1Sim=reshape(re1Sim,size(rx1s));
re2Sim=reshape(re2Sim,size(rx1s));
riSim=reshape(riSim,size(rx1s));

re1Bal=reshape(re1Bal,size(rx1s));
re2Bal=reshape(re2Bal,size(rx1s));
riBal=reshape(riBal,size(rx1s));

re1SemiBal=reshape(re1SemiBal,size(rx1s));
re2SemiBal=reshape(re2SemiBal,size(rx1s));
riSemiBal=reshape(riSemiBal,size(rx1s));


lw=2;
fs=20;

fs=36;

surfclr=[.8 .8 .8];

figure
surf(1000*rx1s(1,:),1000*rx2s(:,1),1000*(re2Sim+re1Sim-.25*riSim))
set(gca,'LineWidth',1)
axis tight
grid off
set(gca,'fontsize',fs)
axis tight
colormap(repmat(surfclr,64,1))
set(gca,'color',[.95 .95 .95])
set(gcf,'Position',[560   528   560*.8   420*.8])


figure
surf(1000*re1Sim,1000*re2Sim,1000*riSim)
set(gca,'LineWidth',1)
axis tight
grid off
set(gca,'fontsize',fs)
axis tight
set(gca,'ZTick',[0 20 40])
colormap(repmat(surfclr,64,1))
set(gca,'view',[-60 20])
set(gca,'color',[.95 .95 .95])
set(gcf,'Position',[560   528   560*.8   420*.8])

