
% Compile C code that calculates rheobase of an EIF
mex CalcRheoBaseEIF.c

% Neuron parameters
taum=15;
EL=-72;
Vth=0;
Vre=-72;
Vlb=-85;
DeltaT=1;
VT=-55;
tauw=200;
a=0;
b=.75;

% Synaptic timescales
taue=8;
taui=4;
taux=10;

% Compute rheobase
rheobase=CalcRheoBaseEIF(taum,1,EL,DeltaT,VT,Vth,Vre,0,100,10000,.1,100)

save AdExRheobase.mat rheobase;
