
clear
close all

tstart=tic;

% Number of neurons in each pop
Ne=8000*3;
Ni=2000*3;
Nx=2000*3;
N=Ne+Ni;

% Number of neurons in each sub-pop
Ne1=round(Ne/2);
Ne2=Ne-Ne1;
Nx1=round(Nx/2);

Ns=[Ne1 Ne2 Ni];
N=sum(Ns);
Nxs=[.5*Nx .5*Nx];
Nx=sum(Nxs); 

% Mean synaptic weights
Jm=15*[25 25 -150;25 25 -150;112.5 112.5 -250]/sqrt(N);
Jxm=15*[180 180;180 180; 135 135]/sqrt(N);

% Connection probabilities
P=[.05 .15 .1;.15 .05 .1; .1 .1 .1];
Px=[.15 0;0 .15; .15 .15];

% In-degrees
K=repmat(Ns,numel(Ns),1).*P;
Kx=repmat(Nxs,numel(Ns),1).*Px;

% Coupling strength coefficient in mV/kHz
JKbar=mean(mean([abs(Jm).*K abs(Jxm).*Kx]));

% Mean-field connectivity (dimensionless)
W=Jm.*K/JKbar;
Wx=Jxm.*Kx/JKbar;

% Neuron parameters
taum=15;
EL=-72;
Vth=0;
Vre=-72;
Vlb=-85;
DeltaT=1;
VT=-55;
tauw=200;
a=0;
b=.75;

% Synaptic timescales
taue=8;
taui=4;
taux=10;

% Conductance-specific stuff
Ee=0;
Ei=-75;
Vbar=-55;

Jmg=zeros(size(Jm));
Jmg(Jm>0)=Jm(Jm>0)/(Ee-Vbar);
Jmg(Jm<0)=Jm(Jm<0)/(Ei-Vbar);

Jxmg=Jxm/(Ee-Vbar);



% Sim time and time step
T=2e3;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Indices of neurons from which to record currents, voltages
Irecord=1:N;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=500;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

% Rate of external population
rx2s=[(0:1.5:9.4)/1000 (9.5:.2:11)/1000 (12:2:20)/1000];
rx1s=10/1000+zeros(size(rx2s));

% Generate connectivity matrices
% Maybe it would be better to do this in a loop
tic
J=[sparse(Jmg(1,1)*binornd(1,P(1,1),Ns(1),Ns(1))) ...
   sparse(Jmg(1,2)*binornd(1,P(1,2),Ns(1),Ns(2))) ...
   sparse(Jmg(1,3)*binornd(1,P(1,3),Ns(1),Ns(3))); ...
   sparse(Jmg(2,1)*binornd(1,P(2,1),Ns(2),Ns(1))) ...
   sparse(Jmg(2,2)*binornd(1,P(2,2),Ns(2),Ns(2))) ...
   sparse(Jmg(2,3)*binornd(1,P(2,3),Ns(2),Ns(3))); ...
   sparse(Jmg(3,1)*binornd(1,P(3,1),Ns(3),Ns(1))) ...
   sparse(Jmg(3,2)*binornd(1,P(3,2),Ns(3),Ns(2))) ...
   sparse(Jmg(3,3)*binornd(1,P(3,3),Ns(3),Ns(3)));];

Jx=[sparse(Jxmg(1,1)*binornd(1,Px(1,1),Ns(1),Nxs(1))) ...
    sparse(Jxmg(1,2)*binornd(1,Px(1,2),Ns(1),Nxs(2))); ...
    sparse(Jxmg(2,1)*binornd(1,Px(2,1),Ns(2),Nxs(1))) ...
    sparse(Jxmg(2,2)*binornd(1,Px(2,2),Ns(2),Nxs(2))); ...
    sparse(Jxmg(3,1)*binornd(1,Px(3,1),Ns(3),Nxs(1))) ...
    sparse(Jxmg(3,2)*binornd(1,Px(3,2),Ns(3),Nxs(2)));];    
tGen=toc
disp(sprintf('\nTime to generate connections: %.2f sec',tGen))

% Compare how fast code is with sparse vs wihtout
% by commenting/uncommenting these lines
J=full(J);
Jx=full(Jx);

muV=zeros(numel(rx2s),1);
sigmaV=zeros(numel(rx2s),1);
muI=zeros(numel(rx2s),1);
sigmaI=zeros(numel(rx2s),1);

muIe=zeros(numel(rx2s),1);
sigmaIe=zeros(numel(rx2s),1);

muIx=zeros(numel(rx2s),1);
sigmaIx=zeros(numel(rx2s),1);

muIex=zeros(numel(rx2s),1);
sigmaIex=zeros(numel(rx2s),1);

beta=zeros(numel(rx2s),1);
muexoversigmaex=zeros(numel(rx2s),1);
%par
for iii=1:numel(rx2s)

    [iii numel(rx2s)]
       
       
    rx2=rx2s(iii);
    rx1=rx1s(iii);
    
    % Make Poisson spike times for ffwd layer    
    nspikeX1=poissrnd(Nxs(1)*rx1*T);
    nspikeX2=poissrnd(Nxs(2)*rx2*T);
    nspikeX=nspikeX1+nspikeX2;
    sx=zeros(2,nspikeX);    
    sx(1,1:nspikeX1)=rand(nspikeX1,1)*T;
    sx(1,nspikeX1+1:nspikeX)=rand(nspikeX2,1)*T;
    sx(2,1:nspikeX1)=randi(Nxs(1),1,nspikeX1);
    sx(2,nspikeX1+1:nspikeX)=Nxs(1)+randi(Nxs(2),1,nspikeX2);
    [st,I]=sort(sx(1,:));
    sx(2,:)=sx(2,I);
    sx(1,:)=st;

    % Random initial voltages
    V0=rand(N,1)*(VT-Vre)+Vre;

    % Maximum number of spikes for all neurons
    % in simulation. Make it 50Hz across all neurons
    % If there are more spikes, the simulation will
    % terminate
    maxns=ceil(.05*N*T);

    % Integer division function
    IntDivide=@(n,k)(floor((n-1)/k)+1);

    % Initialize stuff
    V=V0;
    w=zeros(N,1);

    ge=zeros(N,1);
    gi=zeros(N,1);
    gx=zeros(N,1);
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    geRec=zeros(numrecord,Ntrec);
    giRec=zeros(numrecord,Ntrec);
    gxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);    
    
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    mV=zeros(N,1);
    mV2=zeros(N,1);
    mI=zeros(N,1);
    mI2=zeros(N,1);
    mIex=zeros(N,1);
    mIex2=zeros(N,1);    
    mIe=zeros(N,1);
    mIe2=zeros(N,1); 
    mIx=zeros(N,1);
    mIx2=zeros(N,1); 
    % Euler solver
    tic
    if(nspikeX==0)
        s=zeros(2,0);
    else
    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+ge(Irecord).*(Ee-V(Irecord));
        IiRec(:,ii)=IiRec(:,ii)+gi(Irecord).*(Ei-V(Irecord));
        IxRec(:,ii)=IxRec(:,ii)+gx(Irecord).*(Ee-V(Irecord));
        geRec(:,ii)=geRec(:,ii)+ge(Irecord);
        giRec(:,ii)=giRec(:,ii)+gi(Irecord);
        gxRec(:,ii)=gxRec(:,ii)+gx(Irecord);  
    
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    

        mV=mV+V/numel(time);
        mV2=mV2+V.^2/numel(time);

        Ietemp=ge.*(Ee-V);
        Iitemp=gi.*(Ei-V);
        Ixtemp=gx.*(Ee-V);
        
        mI=mI+(Ietemp+Iitemp+Ixtemp)/numel(time);
        mI2=mI2+(Ietemp+Iitemp+Ixtemp).^2/numel(time);
        
        mIex=mIex+(Ietemp+Ixtemp)/numel(time);
        mIex2=mIex2+(Ietemp+Ixtemp).^2/numel(time);
        
        mIe=mIe+(Ietemp)/numel(time);
        mIe2=mIe2+(Ietemp).^2/numel(time);
        
        mIx=mIx+(Ixtemp)/numel(time);
        mIx2=mIx2+(Ixtemp).^2/numel(time);
        
        
        % Euler update to V
        V=V+(dt/taum)*(ge.*(Ee-V)+gi.*(Ei-V)+gx.*(Ee-V)+(EL-V)+DeltaT*exp((V-VT)/DeltaT));
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;
        
        

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        ge=ge-dt*ge/taue;
        gi=gi-dt*gi/taui;
        gx=gx-dt*gx/taux;    
   

        % If there are spikes
        if(~isempty(Ispike))

            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end

            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
        ge=ge+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
        gi=gi+sum(J(:,Ispike(Ispike>Ne)),2)/taui;             

            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);
        end

        % Propogate ffwd spikes
        while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
            jpre=sx(2,iXspike);
            gx=gx+Jx(:,jpre)/taux;
            iXspike=iXspike+1;
        end

    end
    s=s(:,1:nspike); % Get rid of padding in s
    end    
    if(TooManySpikes)
        warning('\nMax number spikes exceeded, simulation terminated at time t=%1.1f.\n',dt*i)
    end
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    geRec=geRec/nBinsRecord; % Normalize recorded variables by # bins
    giRec=giRec/nBinsRecord;
    gxRec=gxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    reSim(iii)=nnz(s(2,:)<=Ne & s(1,:)>Tburn)/((T-Tburn)*Ne);
    reSim1(iii)=nnz(s(2,:)<=Ne1 & s(1,:)>Tburn)/((T-Tburn)*Ne2);
    reSim2(iii)=nnz(s(2,:)>Ne1 & s(2,:)<=Ne & s(1,:)>Tburn)/((T-Tburn)*Ne1);
    riSim(iii)=nnz(s(2,:)>Ne & s(1,:)>Tburn)/((T-Tburn)*Ni);

    muV(iii)=mean(mV);
    sigmaV(iii)=mean(sqrt(mV2-mV.^2));
    
    muI(iii)=mean(mI);
    sigmaI(iii)=mean(sqrt(mI2-mI.^2));
    
    muIex(iii)=mean(mIex);
    sigmaIex(iii)=mean(sqrt(mIex2-mIex.^2));

    muIe(iii)=mean(mIe);
    sigmaIe(iii)=mean(sqrt(mIe2-mIe.^2));
    
    muIx(iii)=mean(mIx);
    sigmaIx(iii)=mean(sqrt(mIx2-mIx.^2));
        
    beta(iii)=mean(abs(mI)./mIex);
    
    muexoversigmaex(iii)=mean(mIex./sqrt(mIex2-mIex.^2));
    
    rsim=[reSim1(iii);reSim2(iii);riSim(iii)];
  
    rx=[rx1;rx2];
    rTh=-pinv(W)*Wx*rx; 

    reTh1(iii)=rTh(1);
    reTh2(iii)=rTh(2);
    riTh(iii)=rTh(3);

 
    rThReLu=zeros(size(rTh));
    I=find(rTh>0);
    rThReLu(I)=-pinv(W(I,I))*Wx(I,:)*rx;
        
    reTh1ReLu(iii)=rThReLu(1);
    reTh2ReLu(iii)=rThReLu(2);
    riThReLu(iii)=rThReLu(3);
    


end
ttotal=toc(tstart)


clear s st sx J Jee Jei Jie Jii Jx w IeRec Ietemp;
clear IiRec IxRec Ie Ii Ix Irecord Ixtemp Iitemp V V0 VRec;
clear ge gi gx geRec giRec gxRec mI mI2 mIe mIe2 mIex mIex2;
clear mIx mIx2 mV mV2 time;

save Fig2D.mat

%% Load the data and make the plots
load Fig2D.mat


lw=2;
fs=26;
e1clr=[.75 .25 .25];
e2clr=[.85 .65 .65];
iclr=[.25 .25 .85];
xclr=[.25 .75 .25];

Eclr=[.6 .1 .1];
Iclr=[.1 .1 .6];
Tclr=[0 0 0];

I=find(rx2s>=0/1000 & rx2s<=22/1000);

figure
plot(1000*rx2s(I),1000*reSim1(I),'Color',min(1.05*e1clr,1),'LineWidth',lw)
hold on
plot(1000*rx2s(I),1000*reSim2(I),'Color',min(1.05*e2clr,1),'LineWidth',lw)
plot(1000*rx2s(I),1000*riSim(I),'Color',iclr,'LineWidth',lw)
plot(1000*rx2s(I),1000*reTh1ReLu(I),'--','Color',.7*e1clr,'LineWidth',lw)
plot(1000*rx2s(I),1000*reTh2ReLu(I),'--','Color',.7*e2clr,'LineWidth',lw)
plot(1000*rx2s(I),1000*riThReLu(I),'--','Color',iclr,'LineWidth',lw)
xlabel('rx2 (Hz)')
ylabel('rate (Hz)')
axis tight
axis([-Inf Inf -1.5 20])
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gcf,'Position',[153   516   440  300]*.8)


figure
plot(1000*rx2s(I),beta(I),'k','LineWidth',lw)
xlabel('rx2 (Hz)')
ylabel('\beta=abs(E+I)/E')
axis([-Inf Inf 0 .2])
box off
yyaxis right
plot(1000*rx2s(I),abs(muIex(I))./sigmaIex(I),'LineWidth',lw)
axis([-Inf Inf 0 12])
ylabel('c=\mu_E/\sigma_E')
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
box off
set(gcf,'Position',[153   516   440*1.1  300]*.8)


