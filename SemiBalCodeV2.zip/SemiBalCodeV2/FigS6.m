
clear 
close all

% Data for Supp Fig S2 is in Fig4.mat from Fig 4 simulation
load Fig4.mat

lw=2;

% Make plot
fs=26;
figure
plot(100*(1-cumsum(EXPLAINED(1:ndims))./sum(EXPLAINED)),'Color',[.7 .7 .7],'LineWidth',3)
hold on
plot(100*RRR,'Color',[0 0 0],'LineWidth',3)
xlabel('num. dimensions')
ylabel('residual var. (%)')
axis tight
axis([-Inf Inf 0 Inf])
box off
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gcf,'Position',[153   516   440*1  300*1.1]*.8)
