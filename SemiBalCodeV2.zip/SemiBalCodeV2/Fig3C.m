
clear
close all

tstart=tic;

% Number of neurons in each pop
Ne=8000/2%3;
Ni=2000/2%3;
Nx=2000/2%3;
N=Ne+Ni;

% Number of neurons in each sub-pop
Ne1=round(Ne/2);
Ne2=Ne-Ne1;
Nx1=round(Nx/2);

Ns=[Ne1 Ne2 Ni];
N=sum(Ns);
Nxs=[.5*Nx .5*Nx];
Nx=sum(Nxs); 

% Mean synaptic weights
Jm=15*[25 25 -150;25 25 -150;112.5 112.5 -250]/sqrt(N);
Jxm=15*[180 180;180 180; 135 135]/sqrt(N);

% Connection probabilities
P=[.1 .1 .1;.1 .1 .1; .1 .1 .1];
Px=[.1 .1;.1 .1; .1 .1];

% In-degrees
K=repmat(Ns,numel(Ns),1).*P;
Kx=repmat(Nxs,numel(Ns),1).*Px;

% Coupling strength coefficient in mV/kHz
JKbar=mean(mean([abs(Jm).*K abs(Jxm).*Kx]));

% Mean-field connectivity (dimensionless)
W=Jm.*K/JKbar;
Wx=Jxm.*Kx/JKbar;

% Neuron parameters
taum=15;
EL=-72;
Vth=0;
Vre=-72;
Vlb=-85;
DeltaT=1;
VT=-55;
tauw=200;
a=0;
b=.75;

% Synaptic timescales
taue=8;
taui=4;
taux=10;


% Sim time and time step
T=1e3;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);


% Generate connectivity matrices
% Maybe it would be better to do this in a loop
tic
J=[(Jm(1,1)*binornd(1,P(1,1),Ns(1),Ns(1))) ...
   (Jm(1,2)*binornd(1,P(1,2),Ns(1),Ns(2))) ...
   (Jm(1,3)*binornd(1,P(1,3),Ns(1),Ns(3))); ...
   (Jm(2,1)*binornd(1,P(2,1),Ns(2),Ns(1))) ...
   (Jm(2,2)*binornd(1,P(2,2),Ns(2),Ns(2))) ...
   (Jm(2,3)*binornd(1,P(2,3),Ns(2),Ns(3))); ...
   (Jm(3,1)*binornd(1,P(3,1),Ns(3),Ns(1))) ...
   (Jm(3,2)*binornd(1,P(3,2),Ns(3),Ns(2))) ...
   (Jm(3,3)*binornd(1,P(3,3),Ns(3),Ns(3)));];

Jx=[(Jxm(1,1)*binornd(1,Px(1,1),Ns(1),Nxs(1))) ...
    (Jxm(1,2)*binornd(1,Px(1,2),Ns(1),Nxs(2))); ...
    (Jxm(2,1)*binornd(1,Px(2,1),Ns(2),Nxs(1))) ...
    (Jxm(2,2)*binornd(1,Px(2,2),Ns(2),Nxs(2))); ...
    (Jxm(3,1)*binornd(1,Px(3,1),Ns(3),Nxs(1))) ...
    (Jxm(3,2)*binornd(1,Px(3,2),Ns(3),Nxs(2)));];    
tGen=toc
disp(sprintf('\nTime to generate connections: %.2f sec',tGen))


% Random initial voltages
V0=rand(N,1)*(VT-Vre)+Vre;

% Maximum number of spikes for all neurons
% in simulation. Make it 50Hz across all neurons
% If there are more spikes, the simulation will
% terminate
maxns=ceil(.05*N*T);

% Integer division function
IntDivide=@(n,k)(floor((n-1)/k)+1);

% Plasticity params
tauSTDP=200;
rho0=0.005; % Target rate
alpha=2*rho0*tauSTDP;

Z1=randn(N,1);
Z2=randn(N,1);

ntraining1=20;
ntraining2=50;

V=V0;
Ie=zeros(N,1);
Ii=zeros(N,1);
Ix=zeros(N,1);
w=zeros(N,1);
x=zeros(N,1);

sigmaminTrain=-18;
sigmamaxTrain=18;

sigmamin=-18;
sigmamax=18;

% Indices of neurons from which to record currents, voltages
Irecord=1:Ne;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=T%500;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

MeanIe=zeros(ntraining1,numrecord);
MeanIx=zeros(ntraining1,numrecord);
MeanIi=zeros(ntraining1,numrecord);

sigma1=7.5;
sigma2=7.5;

for ijk=1:ntraining1

    [ijk ntraining1]
    if(ijk<=5)
        eta=0;
    else
        eta=0.03;
    end
        
    
    
    %%%%
     rx1=10/1000;
     rx2=10/1000;
    % Make Poisson spike times for ffwd layer    
    nspikeX1=poissrnd(Nxs(1)*rx1*T);
    nspikeX2=poissrnd(Nxs(2)*rx2*T);
    nspikeX=nspikeX1+nspikeX2;
    sx=zeros(2,nspikeX);    
    sx(1,1:nspikeX1)=rand(nspikeX1,1)*T;
    sx(1,nspikeX1+1:nspikeX)=rand(nspikeX2,1)*T;
    sx(2,1:nspikeX1)=randi(Nxs(1),1,nspikeX1);
    sx(2,nspikeX1+1:nspikeX)=Nxs(1)+randi(Nxs(2),1,nspikeX2);
    [st,I]=sort(sx(1,:));
    sx(2,:)=sx(2,I);
    sx(1,:)=st;



    % Initialize stuff
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    % Euler solver
    tic
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    
    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord)+sigma1*Z1(Irecord)+sigma2*Z2(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(sigma1*Z1+sigma2*Z2+Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))


            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            


            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end


            % If there is plasticity
            if(eta~=0)
                % Update synaptic weights according to plasticity rules
                % I to E after an I spike    
                J(1:Ne,Ispike(Ispike>Ne))=J(1:Ne,Ispike(Ispike>Ne))+ ... 
                    -repmat(eta*(x(1:Ne)-alpha),1,nnz(Ispike>Ne)).*(J(1:Ne,Ispike(Ispike>Ne))~=0);
                % E to I after an E spike
                J(Ispike(Ispike<=Ne),Ne+1:N)=J(Ispike(Ispike<=Ne),Ne+1:N)+ ... 
                    -repmat(eta*x(Ne+1:N)',nnz(Ispike<=Ne),1).*(J(Ispike(Ispike<=Ne),Ne+1:N)~=0);
            end

            % Update rate estimates for plasticity rules
            x(Ispike)=x(Ispike)+1;


            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);



        end

        % Propogate ffwd spikes
        while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
            jpre=sx(2,iXspike);
            Ix=Ix+Jx(:,jpre)/taux;
            iXspike=iXspike+1;
        end


        % Update time-dependent firing rates for plasticity
        x(1:Ne)=x(1:Ne)-dt*x(1:Ne)/tauSTDP;
        x(Ne+1:end)=x(Ne+1:end)-dt*x(Ne+1:end)/tauSTDP;


    end
    
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    

    MeanIe(ijk,:)=IeRec(:,1);
    MeanIi(ijk,:)=IiRec(:,1);
    MeanIx(ijk,:)=IxRec(:,1);
    
    nnz(s(2,:)<=Ne & s(2,:)>0)/(Ne*T)

end

%%%%

for ijk=1:ntraining2

    
    %%%%
     rx1=10/1000;
     rx2=10/1000;
    % Make Poisson spike times for ffwd layer    
    nspikeX1=poissrnd(Nxs(1)*rx1*T);
    nspikeX2=poissrnd(Nxs(2)*rx2*T);
    nspikeX=nspikeX1+nspikeX2;
    sx=zeros(2,nspikeX);    
    sx(1,1:nspikeX1)=rand(nspikeX1,1)*T;
    sx(1,nspikeX1+1:nspikeX)=rand(nspikeX2,1)*T;
    sx(2,1:nspikeX1)=randi(Nxs(1),1,nspikeX1);
    sx(2,nspikeX1+1:nspikeX)=Nxs(1)+randi(Nxs(2),1,nspikeX2);
    [st,I]=sort(sx(1,:));
    sx(2,:)=sx(2,I);
    sx(1,:)=st;


    sigma1=((sigmamaxTrain-sigmaminTrain)*rand()+sigmaminTrain);
    sigma2=((sigmamaxTrain-sigmaminTrain)*rand()+sigmaminTrain);

    % Initialize stuff
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;
    % Euler solver
    tic
    
    for i=1:numel(time)



        % Euler update to V
        V=V+(dt/taum)*(sigma1*Z1+sigma2*Z2+Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))


            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            


            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end


            % If there is plasticity
            if(eta~=0)
                % Update synaptic weights according to plasticity rules
                % I to E after an I spike    
                J(1:Ne,Ispike(Ispike>Ne))=J(1:Ne,Ispike(Ispike>Ne))+ ... 
                    -repmat(eta*(x(1:Ne)-alpha),1,nnz(Ispike>Ne)).*(J(1:Ne,Ispike(Ispike>Ne))~=0);
                % E to I after an E spike
                J(Ispike(Ispike<=Ne),Ne+1:N)=J(Ispike(Ispike<=Ne),Ne+1:N)+ ... 
                    -repmat(eta*x(Ne+1:N)',nnz(Ispike<=Ne),1).*(J(Ispike(Ispike<=Ne),Ne+1:N)~=0);
            end

            % Update rate estimates for plasticity rules
            x(Ispike)=x(Ispike)+1;


            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);



        end

        % Propogate ffwd spikes
        while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
            jpre=sx(2,iXspike);
            Ix=Ix+Jx(:,jpre)/taux;
            iXspike=iXspike+1;
        end


        % Update time-dependent firing rates for plasticity
        x(1:Ne)=x(1:Ne)-dt*x(1:Ne)/tauSTDP;
        x(Ne+1:end)=x(Ne+1:end)-dt*x(Ne+1:end)/tauSTDP;


    end
    
    

    nnz(s(2,:)<=Ne & s(2,:)>0)/(Ne*T)

end

%%%%

% Sim time and time step
T=4e5;
Tburn=500;
dt=.1;
time=dt:dt:T;
Nt=numel(time);

% Indices of neurons from which to record currents, voltages
Irecord=1:N;
numrecord=numel(Irecord);

% Time discretization of recordings. This can be coarser 
% than the dt for the Euler solver. If so, it will record
% the average current across each coarser time bin
dtRecord=T;
nBinsRecord=round(dtRecord/dt);
timeRecord=dtRecord:dtRecord:T;
Ntrec=numel(timeRecord);

% Rate of external population
[sigma1s,sigma2s]=meshgrid(sigmamin:2.25:sigmamax,sigmamin:2.25:sigmamax);

rSimAll=zeros(numel(sigma1s),N);
IeAll=zeros(numel(sigma1s),N);
IiAll=zeros(numel(sigma1s),N);
IxAll=zeros(numel(sigma1s),N);
VAll=zeros(numel(sigma1s),N);
parpool(11)
parfor iii=1:numel(sigma1s)

    [iii numel(sigma1s)]
       
    sigma1=sigma1s(iii);
    sigma2=sigma2s(iii);
    %rx2=rx2s(iii);
    %rx1=rx1s(iii);
    
    % Make Poisson spike times for ffwd layer    
    nspikeX1=poissrnd(Nxs(1)*rx1*T);
    nspikeX2=poissrnd(Nxs(2)*rx2*T);
    nspikeX=nspikeX1+nspikeX2;
    sx=zeros(2,nspikeX);    
    sx(1,1:nspikeX1)=rand(nspikeX1,1)*T;
    sx(1,nspikeX1+1:nspikeX)=rand(nspikeX2,1)*T;
    sx(2,1:nspikeX1)=randi(Nxs(1),1,nspikeX1);
    sx(2,nspikeX1+1:nspikeX)=Nxs(1)+randi(Nxs(2),1,nspikeX2);
    [st,I]=sort(sx(1,:));
    sx(2,:)=sx(2,I);
    sx(1,:)=st;

    % Random initial voltages
    V0=rand(N,1)*(VT-Vre)+Vre;

    % Maximum number of spikes for all neurons
    % in simulation. Make it 50Hz across all neurons
    % If there are more spikes, the simulation will
    % terminate
    maxns=ceil(.05*N*T);

    % Integer division function
    IntDivide=@(n,k)(floor((n-1)/k)+1);

    % Initialize stuff
    V=V0;
    w=zeros(N,1);
    Ie=zeros(N,1);
    Ii=zeros(N,1);
    Ix=zeros(N,1);
    IeRec=zeros(numrecord,Ntrec);
    IiRec=zeros(numrecord,Ntrec);
    IxRec=zeros(numrecord,Ntrec);
    VRec=zeros(numrecord,Ntrec);
    iXspike=1;
    s=zeros(2,maxns);
    nspike=0;
    TooManySpikes=0;

    % Euler solver
    tic
    for i=1:numel(time)

        % Store recorded variables
        ii=IntDivide(i,nBinsRecord); 
        IeRec(:,ii)=IeRec(:,ii)+Ie(Irecord);
        IiRec(:,ii)=IiRec(:,ii)+Ii(Irecord);
        IxRec(:,ii)=IxRec(:,ii)+Ix(Irecord)+sigma1*Z1(Irecord)+sigma2*Z2(Irecord);
        VRec(:,ii)=VRec(:,ii)+V(Irecord);    


        % Euler update to V
        V=V+(dt/taum)*(sigma1*Z1+sigma2*Z2+Ie+Ii+Ix+(EL-V)+DeltaT*exp((V-VT)/DeltaT)-w);
        V=max(V,Vlb);
        w=w-(dt/tauw)*w;

        % Find which neurons spiked
        Ispike=find(V>=Vth);    

        % Euler update to synaptic currents
        Ie=Ie-dt*Ie/taue;
        Ii=Ii-dt*Ii/taui;
        Ix=Ix-dt*Ix/taux;    

        % If there are spikes
        if(~isempty(Ispike))

            % Store spike times and neuron indices
            if(nspike+numel(Ispike)<=maxns)
                s(1,nspike+1:nspike+numel(Ispike))=time(i);
                s(2,nspike+1:nspike+numel(Ispike))=Ispike;
            else
                TooManySpikes=1;
                break;
            end

            % Reset mem pot.
            V(Ispike)=Vre;
            w(Ispike)=w(Ispike)+b;

            % Update synaptic currents
            Ie=Ie+sum(J(:,Ispike(Ispike<=Ne)),2)/taue;    
            Ii=Ii+sum(J(:,Ispike(Ispike>Ne)),2)/taui;            

            % Update cumulative number of spikes
            nspike=nspike+numel(Ispike);
        end

        % Propogate ffwd spikes
        while(sx(1,iXspike)<=time(i) && iXspike<nspikeX)
            jpre=sx(2,iXspike);
            Ix=Ix+Jx(:,jpre)/taux;
            iXspike=iXspike+1;
        end

    end
    s=s(:,1:nspike); % Get rid of padding in s
    
    if(TooManySpikes)
        warning('\nMax number spikes exceeded, simulation terminated at time t=%1.1f.\n',dt*i)
    end
    IeRec=IeRec/nBinsRecord; % Normalize recorded variables by # bins
    IiRec=IiRec/nBinsRecord;
    IxRec=IxRec/nBinsRecord;
    VRec=VRec/nBinsRecord;
    
    rSimAll(iii,:)=hist(s(2,s(1,:)>=Tburn),1:N)/(T-Tburn);
    IeAll(iii,:)=IeRec;
    IiAll(iii,:)=IiRec;
    IxAll(iii,:)=IxRec;
    VAll(iii,:)=VRec;
end

ttotal=toc(tstart)

clear s st sx J Jee Jei Jie Jii Jx;
rSimAll=rSimAll(:,1:Ne);
clear time IeAll IiAll IxAll VAll IeRec IiRec IxRec VRec MeanIe MeanIi MeanIx;
save Fig3C.mat

%%

load Fig3C.mat


lw=2;
fs=20;

% This code will produce new, randomly chosen 
% manifold and tuning surfaces every time it is run
i=randi(Ne);
j=randi(Ne);
k=randi(Ne);

figure
surf(1000*reshape(rSimAll(:,i),size(sigma1s)),1000*reshape(rSimAll(:,j),size(sigma1s)),1000*reshape(rSimAll(:,k),size(sigma1s)))
set(gca,'LineWidth',1)
axis tight
axis([0 Inf 0 Inf 0 Inf])
grid off
set(gca,'fontsize',fs)
colormap default
set(gca,'color',[.95 .95 .95])
set(gcf,'Position',[560   528   560*.8   420*.8])

i=randi(Ne);
figure
surf(sigma1s,sigma2s,1000*reshape(rSimAll(:,i),size(sigma1s)))
set(gca,'LineWidth',1)
axis tight
axis([-Inf Inf -Inf Inf 0 Inf])
grid off
set(gca,'fontsize',fs)
set(gca,'color',[.95 .95 .95])
set(gcf,'Position',[560   528   560*.8   420*.8])
xlabel('\sigma_1')
ylabel('\sigma_2')



% Perform PCA and ISOMAP analysis
ndims=12;
ncells=Ne;
options.dims=1:ndims;
x=rSimAll(:,1:ncells);
D=sqdist(x',x');
[Y, R, E] = IsoMap(D, 'k',5,options);
[COEFF, SCORE, LATENT, TSQUARED, EXPLAINED] = pca(x);

fs=26;
figure
plot(100*(1-cumsum(EXPLAINED(1:ndims))./sum(EXPLAINED)),'Color',[.7 .7 .7],'LineWidth',3)
hold on
plot(100*R,'Color',[0 0 0],'LineWidth',3)
xlabel('num. dimensions')
ylabel('residual var. (%)')
axis tight
axis([-Inf Inf 0 50])
box off
set(gca,'YTick',[0 25 50])
set(gca,'FontSize',fs)
set(gca,'LineWidth',lw)
set(gcf,'Position',[153   516   440*1  300*1.1]*.8)



